<?php
require 'config.php';
require 'includes/auth.php';
require_login();
$user = current_user();

$bundle_id = (int)($_GET['bundle_id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM bundles WHERE id = ? AND user_id = ?");
$stmt->execute([$bundle_id, $user['id']]);
$bundle = $stmt->fetch();
if (!$bundle) { header('Location: dashboard.php'); exit; }

$stmt = $pdo->prepare("SELECT * FROM contacts WHERE bundle_id = ? ORDER BY created_at ASC");
$stmt->execute([$bundle_id]);
$contacts = $stmt->fetchAll();

$filename = preg_replace('/[^A-Za-z0-9_-]/', '_', $bundle['name']) . '.csv';

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$out = fopen('php://output', 'w');
fputcsv($out, ['Full Name', 'Country Code', 'Phone', 'Date Added']);
foreach ($contacts as $c) {
    fputcsv($out, [$c['full_name'], $c['country_code'], $c['phone'], $c['created_at']]);
}
fclose($out);

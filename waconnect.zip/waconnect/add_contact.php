<?php
require 'config.php';
require 'includes/auth.php';
require_login();
$user = current_user();

$bundle_id = (int)($_GET['bundle_id'] ?? $_POST['bundle_id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM bundles WHERE id = ? AND user_id = ?");
$stmt->execute([$bundle_id, $user['id']]);
$bundle = $stmt->fetch();
if (!$bundle) { header('Location: dashboard.php'); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $country_code = trim($_POST['country_code'] ?? '+234');
    $phone = trim($_POST['phone'] ?? '');

    if (!$full_name || !$phone) {
        $error = 'Name and phone are required.';
    } else {
        $clean_phone = preg_replace('/\D/', '', $phone);
        $stmt = $pdo->prepare("INSERT INTO contacts (bundle_id, full_name, country_code, phone) VALUES (?,?,?,?)");
        $stmt->execute([$bundle_id, $full_name, $country_code, $clean_phone]);
        header('Location: view_contacts.php?bundle_id=' . $bundle_id);
        exit;
    }
}

$page_title = 'Add Contact';
require 'includes/header.php';
?>
<div class="bg-white rounded-2xl shadow p-6">
  <h1 class="text-2xl font-bold mb-1">Add Contact</h1>
  <p class="text-gray-500 mb-6">to <?php echo h($bundle['name']); ?></p>
  <?php if ($error): ?>
    <div class="bg-red-50 text-red-600 text-sm rounded-lg px-3 py-2 mb-4"><?php echo h($error); ?></div>
  <?php endif; ?>
  <form method="post" class="space-y-4">
    <input type="hidden" name="bundle_id" value="<?php echo $bundle_id; ?>">
    <input name="full_name" placeholder="Full Name" required class="w-full border rounded-lg px-3 py-2.5">
    <div class="flex gap-2">
      <select name="country_code" class="border rounded-lg px-2 py-2.5 w-28">
        <option value="+234" selected>🇳🇬 +234</option>
        <option value="+233">🇬🇭 +233</option>
        <option value="+254">🇰🇪 +254</option>
        <option value="+1">🇺🇸 +1</option>
        <option value="+44">🇬🇧 +44</option>
      </select>
      <input name="phone" placeholder="Phone Number" required class="flex-1 border rounded-lg px-3 py-2.5">
    </div>
    <button class="w-full brand-gradient text-white font-semibold rounded-lg py-3">Add Contact</button>
  </form>
  <a href="bundle.php?id=<?php echo $bundle_id; ?>" class="block text-center text-purple-600 mt-4">&larr; Back to bundle</a>
</div>
<?php require 'includes/footer.php'; ?>

<?php
require 'config.php';
require 'includes/auth.php';
require_login();
$user = current_user();

$id = (int)($_POST['id'] ?? 0);
$bundle_id = (int)($_POST['bundle_id'] ?? 0);

$stmt = $pdo->prepare("DELETE c FROM contacts c JOIN bundles b ON b.id = c.bundle_id WHERE c.id = ? AND b.user_id = ?");
$stmt->execute([$id, $user['id']]);

header('Location: view_contacts.php?bundle_id=' . $bundle_id . '&edit=1');
exit;

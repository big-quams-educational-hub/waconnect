<?php
require 'config.php';
require 'includes/auth.php';
require_login();
$user = current_user();

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM bundles WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $user['id']]);
$current = $stmt->fetch();
if (!$current) { header('Location: dashboard.php'); exit; }

$stmt = $pdo->prepare("SELECT b.*, (SELECT COUNT(*) FROM contacts c WHERE c.bundle_id = b.id) as contact_count
                        FROM bundles b WHERE b.user_id = ? AND b.id != ? ORDER BY b.created_at DESC");
$stmt->execute([$user['id'], $id]);
$others = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selected = array_map('intval', $_POST['bundle_ids'] ?? []);
    $selected[] = $id; // always include current
    $selected = array_unique($selected);

    // Verify ownership of all selected bundles
    $placeholders = implode(',', array_fill(0, count($selected), '?'));
    $stmt = $pdo->prepare("SELECT b.name, c.full_name, c.country_code, c.phone
                            FROM contacts c JOIN bundles b ON b.id = c.bundle_id
                            WHERE b.id IN ($placeholders) AND b.user_id = ?
                            ORDER BY c.created_at ASC");
    $stmt->execute([...$selected, $user['id']]);
    $rows = $stmt->fetchAll();

    $filename = 'combined_' . date('Ymd_His') . '.vcf';
    header('Content-Type: text/vcard; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    foreach ($rows as $r) {
        echo "BEGIN:VCARD\r\n";
        echo "VERSION:3.0\r\n";
        echo "FN:" . $r['full_name'] . "\r\n";
        echo "TEL;TYPE=CELL:" . $r['country_code'] . $r['phone'] . "\r\n";
        echo "END:VCARD\r\n";
    }
    exit;
}

$page_title = 'Combine VCFs';
require 'includes/header.php';
?>
<div class="bg-white rounded-2xl shadow p-6">
  <h1 class="text-2xl font-bold mb-1">Combine VCFs</h1>
  <p class="text-gray-500 mb-6">Merging into: <strong><?php echo h($current['name']); ?></strong>. Pick other bundles to include.</p>

  <?php if (!$others): ?>
    <p class="text-gray-400 text-center py-6">You don't have any other bundles yet.</p>
  <?php else: ?>
    <form method="post" class="space-y-3">
      <?php foreach ($others as $b): ?>
        <label class="flex items-center justify-between border rounded-lg px-4 py-3 cursor-pointer">
          <span>
            <input type="checkbox" name="bundle_ids[]" value="<?php echo $b['id']; ?>" class="mr-3">
            <?php echo h($b['name']); ?>
          </span>
          <span class="text-sm text-gray-400"><?php echo $b['contact_count']; ?> contacts</span>
        </label>
      <?php endforeach; ?>
      <button class="w-full brand-gradient text-white font-semibold rounded-lg py-3 mt-4">Download Combined VCF</button>
    </form>
  <?php endif; ?>

  <a href="bundle.php?id=<?php echo $id; ?>" class="block text-center text-purple-600 mt-6">&larr; Back to bundle</a>
</div>
<?php require 'includes/footer.php'; ?>

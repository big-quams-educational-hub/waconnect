<?php
require 'config.php';
require 'includes/auth.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $business_name = trim($_POST['business_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $country_code = trim($_POST['country_code'] ?? '+234');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (!$business_name || !$email || !$password) {
        $error = 'Please fill in all required fields.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'An account with this email already exists.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (business_name, email, country_code, phone, password_hash) VALUES (?,?,?,?,?)");
            $stmt->execute([$business_name, $email, $country_code, $phone, $hash]);
            $_SESSION['user_id'] = $pdo->lastInsertId();
            header('Location: dashboard.php');
            exit;
        }
    }
}

$page_title = 'Register';
require 'includes/header.php';
?>
<div class="bg-white rounded-2xl shadow p-6 max-w-md mx-auto">
  <h1 class="text-2xl font-bold text-center mb-6">Create your account</h1>
  <?php if ($error): ?>
    <div class="bg-red-50 text-red-600 text-sm rounded-lg px-3 py-2 mb-4"><?php echo h($error); ?></div>
  <?php endif; ?>
  <form method="post" class="space-y-4">
    <input name="business_name" placeholder="Business Name" required
      value="<?php echo h($_POST['business_name'] ?? ''); ?>"
      class="w-full border rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-purple-500">
    <input name="email" type="email" placeholder="Email" required
      value="<?php echo h($_POST['email'] ?? ''); ?>"
      class="w-full border rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-purple-500">
    <div class="flex gap-2">
      <select name="country_code" class="border rounded-lg px-2 py-2.5 w-28">
        <option value="+234" selected>🇳🇬 +234</option>
        <option value="+233">🇬🇭 +233</option>
        <option value="+254">🇰🇪 +254</option>
        <option value="+1">🇺🇸 +1</option>
        <option value="+44">🇬🇧 +44</option>
      </select>
      <input name="phone" placeholder="Phone Number"
        class="flex-1 border rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-purple-500">
    </div>
    <input name="password" type="password" placeholder="Password" required
      class="w-full border rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-purple-500">
    <input name="confirm_password" type="password" placeholder="Confirm Password" required
      class="w-full border rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-purple-500">
    <button class="w-full brand-gradient text-white font-semibold rounded-lg py-2.5 hover:opacity-90">Register</button>
  </form>
  <p class="text-center text-sm text-gray-500 mt-4">Already have an account? <a href="login.php" class="text-purple-600 font-medium">Login</a></p>
</div>
<?php require 'includes/footer.php'; ?>

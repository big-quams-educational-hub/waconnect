<?php
require 'config.php';
require 'includes/auth.php';
require_login();
$user = current_user();

$bundle_id = (int)($_GET['bundle_id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM bundles WHERE id = ? AND user_id = ?");
$stmt->execute([$bundle_id, $user['id']]);
$bundle = $stmt->fetch();
if (!$bundle) { header('Location: dashboard.php'); exit; }

$stmt = $pdo->prepare("SELECT * FROM contacts WHERE bundle_id = ? ORDER BY created_at ASC");
$stmt->execute([$bundle_id]);
$contacts = $stmt->fetchAll();

/**
 * Minimal, dependency-free PDF generator.
 * Produces a simple text listing of contacts, paginated automatically.
 */
function pdf_escape($s) {
    return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $s);
}

function build_simple_pdf($title, array $lines) {
    $lines_per_page = 45;
    $pages = array_chunk($lines, $lines_per_page);
    if (!$pages) $pages = [[]];

    $objects = [];
    $objects[] = "<< /Type /Catalog /Pages 2 0 R >>"; // 1: Catalog

    $kids = [];
    $page_obj_start = 4; // object numbers for pages start after font (3)
    $content_obj_start = $page_obj_start + count($pages);

    foreach ($pages as $i => $page_lines) {
        $kids[] = ($page_obj_start + $i) . " 0 R";
    }
    $objects[] = "<< /Type /Pages /Kids [" . implode(' ', $kids) . "] /Count " . count($pages) . " >>"; // 2: Pages
    $objects[] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"; // 3: Font

    foreach ($pages as $i => $page_lines) {
        $content_ref = $content_obj_start + $i;
        $objects[] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents {$content_ref} 0 R >>";
    }

    foreach ($pages as $i => $page_lines) {
        $y = 800;
        $stream = "BT /F1 14 Tf 40 " . $y . " Td (" . pdf_escape($title . ($i === 0 ? '' : ' (cont.)')) . ") Tj ET\n";
        $y -= 30;
        $stream .= "BT /F1 10 Tf\n";
        $first = true;
        foreach ($page_lines as $line) {
            if ($first) {
                $stream .= "40 {$y} Td (" . pdf_escape($line) . ") Tj\n";
                $first = false;
            } else {
                $stream .= "0 -16 Td (" . pdf_escape($line) . ") Tj\n";
            }
        }
        $stream .= "ET";
        $objects[] = ["stream" => $stream];
    }

    // Assemble PDF
    $pdf = "%PDF-1.4\n";
    $offsets = [];
    $obj_num = 1;
    foreach ($objects as $obj) {
        $offsets[$obj_num] = strlen($pdf);
        if (is_array($obj)) {
            $len = strlen($obj['stream']);
            $pdf .= "{$obj_num} 0 obj\n<< /Length {$len} >>\nstream\n" . $obj['stream'] . "\nendstream\nendobj\n";
        } else {
            $pdf .= "{$obj_num} 0 obj\n{$obj}\nendobj\n";
        }
        $obj_num++;
    }

    $xref_offset = strlen($pdf);
    $total = $obj_num - 1;
    $pdf .= "xref\n0 " . ($total + 1) . "\n0000000000 65535 f \n";
    for ($n = 1; $n <= $total; $n++) {
        $pdf .= sprintf("%010d 00000 n \n", $offsets[$n]);
    }
    $pdf .= "trailer\n<< /Size " . ($total + 1) . " /Root 1 0 R >>\nstartxref\n{$xref_offset}\n%%EOF";

    return $pdf;
}

$lines = [];
$lines[] = str_pad('Full Name', 35) . str_pad('Country', 10) . 'Phone';
$lines[] = str_repeat('-', 70);
foreach ($contacts as $c) {
    $lines[] = str_pad(substr($c['full_name'], 0, 33), 35) . str_pad($c['country_code'], 10) . $c['phone'];
}
if (!$contacts) $lines[] = '(No contacts yet)';

$pdf_data = build_simple_pdf($bundle['name'] . ' - Contacts', $lines);
$filename = preg_replace('/[^A-Za-z0-9_-]/', '_', $bundle['name']) . '.pdf';

header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($pdf_data));
echo $pdf_data;

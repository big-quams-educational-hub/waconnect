<?php
require 'config.php';
require 'includes/auth.php';
require_login();
$user = current_user();

$bundle_id = (int)($_GET['bundle_id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM bundles WHERE id = ? AND user_id = ?");
$stmt->execute([$bundle_id, $user['id']]);
$bundle = $stmt->fetch();
if (!$bundle) { header('Location: dashboard.php'); exit; }

$edit_mode = isset($_GET['edit']);

$stmt = $pdo->prepare("SELECT * FROM contacts WHERE bundle_id = ? ORDER BY created_at DESC");
$stmt->execute([$bundle_id]);
$contacts = $stmt->fetchAll();

$page_title = 'Contacts';
require 'includes/header.php';
?>
<div class="bg-white rounded-2xl shadow p-6">
  <div class="flex items-center justify-between mb-1">
    <h1 class="text-2xl font-bold"><?php echo h($bundle['name']); ?></h1>
    <span class="bg-blue-50 text-blue-600 text-sm font-medium px-3 py-1 rounded-full"><?php echo count($contacts); ?> contacts</span>
  </div>
  <p class="text-gray-500 mb-4"><?php echo $edit_mode ? 'Edit contacts' : 'All contacts'; ?></p>

  <?php if (!$contacts): ?>
    <p class="text-gray-400 text-center py-6">No contacts yet.</p>
  <?php endif; ?>

  <div class="space-y-2">
    <?php foreach ($contacts as $c): ?>
      <div class="border rounded-lg px-4 py-3 flex items-center justify-between">
        <div>
          <div class="font-medium"><?php echo h($c['full_name']); ?></div>
          <div class="text-sm text-gray-500"><?php echo h($c['country_code'] . $c['phone']); ?></div>
        </div>
        <?php if ($edit_mode): ?>
          <div class="flex gap-2">
            <a href="edit_contact.php?id=<?php echo $c['id']; ?>&bundle_id=<?php echo $bundle_id; ?>" class="text-purple-600 text-sm font-medium">Edit</a>
            <form method="post" action="delete_contact.php" onsubmit="return confirm('Delete this contact?');">
              <input type="hidden" name="id" value="<?php echo $c['id']; ?>">
              <input type="hidden" name="bundle_id" value="<?php echo $bundle_id; ?>">
              <button class="text-red-500 text-sm font-medium">Delete</button>
            </form>
          </div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>

  <a href="bundle.php?id=<?php echo $bundle_id; ?>" class="block text-center text-purple-600 mt-6">&larr; Back to bundle</a>
</div>
<?php require 'includes/footer.php'; ?>

<?php
require 'config.php';
require 'includes/auth.php';
require_login();
$user = current_user();

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM bundles WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $user['id']]);
$bundle = $stmt->fetch();
if (!$bundle) { header('Location: dashboard.php'); exit; }

$stmt = $pdo->prepare("SELECT COUNT(*) c FROM contacts WHERE bundle_id = ?");
$stmt->execute([$id]);
$count = $stmt->fetch()['c'];

$share_link = BASE_URL . '/form.php?ref=' . $bundle['ref_code'];

if (isset($_GET['deleted'])) {
    header('Location: dashboard.php');
    exit;
}

$page_title = $bundle['name'];
require 'includes/header.php';
?>
<div class="bg-white rounded-2xl shadow p-6">
  <div class="flex items-center justify-between mb-2">
    <h1 class="text-2xl font-bold"><?php echo h($bundle['name']); ?></h1>
    <span class="bg-blue-50 text-blue-600 text-sm font-medium px-3 py-1 rounded-full"><?php echo $count; ?> contacts</span>
  </div>
  <hr class="my-4">

  <h3 class="text-gray-500 font-semibold text-sm mb-2">ACTIONS</h3>
  <div class="grid gap-2 mb-4">
    <a href="add_contact.php?bundle_id=<?php echo $id; ?>" class="bg-gray-50 rounded-lg px-4 py-3 font-medium hover:bg-gray-100">+ Add Contact</a>
    <a href="view_contacts.php?bundle_id=<?php echo $id; ?>" class="bg-gray-50 rounded-lg px-4 py-3 font-medium hover:bg-gray-100">👥 View Contacts</a>
  </div>

  <h3 class="text-gray-500 font-semibold text-sm mb-2">SHARE</h3>
  <div class="grid gap-2 mb-4">
    <button onclick="copyLink()" class="bg-gray-50 rounded-lg px-4 py-3 font-medium hover:bg-gray-100 text-left">🔗 Copy Link</button>
    <a href="https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=<?php echo urlencode($share_link); ?>" target="_blank" class="bg-gray-50 rounded-lg px-4 py-3 font-medium hover:bg-gray-100">▦ QR Code</a>
  </div>
  <p class="text-xs text-gray-400 mb-4 break-all">Public link: <?php echo h($share_link); ?></p>

  <h3 class="text-gray-500 font-semibold text-sm mb-2">EXPORT</h3>
  <div class="grid gap-2 mb-4">
    <a href="export_vcf.php?bundle_id=<?php echo $id; ?>" class="bg-gray-50 rounded-lg px-4 py-3 font-medium hover:bg-gray-100">📄 Download VCF</a>
    <a href="export_pdf.php?bundle_id=<?php echo $id; ?>" class="bg-gray-50 rounded-lg px-4 py-3 font-medium hover:bg-gray-100">📕 Download PDF</a>
    <a href="export_csv.php?bundle_id=<?php echo $id; ?>" class="bg-gray-50 rounded-lg px-4 py-3 font-medium hover:bg-gray-100">📊 Download CSV</a>
  </div>

  <div class="grid gap-3 mt-4">
    <a href="view_contacts.php?bundle_id=<?php echo $id; ?>&edit=1" class="brand-gradient text-white text-center font-semibold rounded-lg py-3">✎ Edit Contacts</a>
    <a href="edit_bundle.php?id=<?php echo $id; ?>" class="brand-gradient text-white text-center font-semibold rounded-lg py-3">✎ Edit VCF Details</a>
    <form method="post" action="delete_bundle.php" onsubmit="return confirm('Delete this bundle and all its contacts? This cannot be undone.');">
      <input type="hidden" name="id" value="<?php echo $id; ?>">
      <button class="w-full bg-gray-100 text-gray-700 font-semibold rounded-lg py-3">🗑 Delete</button>
    </form>
    <a href="combine.php?id=<?php echo $id; ?>" class="bg-gray-100 text-gray-700 text-center font-semibold rounded-lg py-3">⧉ Combine VCFs</a>
  </div>
</div>

<script>
function copyLink() {
  navigator.clipboard.writeText(<?php echo json_encode($share_link); ?>).then(()=> alert('Link copied!'));
}
</script>
<?php require 'includes/footer.php'; ?>

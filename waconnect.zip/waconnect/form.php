<?php
require 'config.php';
require 'includes/auth.php';

$ref = $_GET['ref'] ?? '';
$stmt = $pdo->prepare("SELECT b.*, u.business_name FROM bundles b JOIN users u ON u.id = b.user_id WHERE b.ref_code = ?");
$stmt->execute([$ref]);
$bundle = $stmt->fetch();

if (!$bundle) {
    http_response_code(404);
    echo "Link not found or expired.";
    exit;
}

// Check expiry
$created = strtotime($bundle['created_at']);
$expires = $created + $bundle['release_days'] * 86400;
$expired = time() > $expires;

// Check max members
$stmt = $pdo->prepare("SELECT COUNT(*) c FROM contacts WHERE bundle_id = ?");
$stmt->execute([$bundle['id']]);
$count = $stmt->fetch()['c'];
$full = $bundle['max_members'] > 0 && $count >= $bundle['max_members'];

$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$expired && !$full) {
    $full_name = trim($_POST['full_name'] ?? '');
    $country_code = trim($_POST['country_code'] ?? '+234');
    $phone = trim($_POST['phone'] ?? '');
    $agree = isset($_POST['agree']);

    if (!$full_name || !$phone) {
        $error = 'Please fill in your name and phone number.';
    } elseif (!$agree) {
        $error = 'You must agree to the Terms and Privacy Policy.';
    } else {
        if ($bundle['suffix']) {
            $full_name = $full_name . ' ' . $bundle['suffix'];
        }
        $clean_phone = preg_replace('/\D/', '', $phone);
        $stmt = $pdo->prepare("INSERT INTO contacts (bundle_id, full_name, country_code, phone) VALUES (?,?,?,?)");
        $stmt->execute([$bundle['id'], $full_name, $country_code, $clean_phone]);
        $success = true;
    }
}

$page_title = $bundle['business_name'];
require 'includes/header.php';
?>
<div class="bg-white rounded-2xl shadow overflow-hidden mb-6">
  <div class="brand-gradient text-white px-6 py-5">
    <h1 class="text-xl font-bold flex items-center gap-2">👤+ Contact Information</h1>
  </div>
  <div class="p-6">
    <?php if ($success): ?>
      <div class="text-center py-6">
        <div class="text-5xl mb-3">✅</div>
        <h2 class="text-xl font-bold mb-2">Thank you!</h2>
        <p class="text-gray-500">Your contact was submitted successfully<?php echo $bundle['whatsapp_link'] ? '.' : '.'; ?></p>
        <?php if ($bundle['whatsapp_link']): ?>
          <a href="<?php echo h($bundle['whatsapp_link']); ?>" class="inline-block mt-4 bg-green-500 text-white font-semibold rounded-lg px-5 py-2.5">Join our WhatsApp group</a>
        <?php endif; ?>
      </div>
    <?php elseif ($expired): ?>
      <p class="text-center text-gray-500 py-6">This link has expired. Please contact <?php echo h($bundle['business_name']); ?> for a new link.</p>
    <?php elseif ($full): ?>
      <p class="text-center text-gray-500 py-6">This bundle has reached its maximum number of contacts.</p>
    <?php else: ?>
      <?php if ($error): ?>
        <div class="bg-red-50 text-red-600 text-sm rounded-lg px-3 py-2 mb-4"><?php echo h($error); ?></div>
      <?php endif; ?>
      <form method="post" class="space-y-4">
        <div>
          <label class="block font-medium mb-1">Full Name</label>
          <input name="full_name" placeholder="Enter your full name" required
            class="w-full border rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-purple-500">
        </div>
        <div>
          <label class="block font-medium mb-1">Country Code</label>
          <select name="country_code" class="w-full border rounded-lg px-3 py-2.5">
            <option value="+234" selected>🇳🇬 Nigeria (+234)</option>
            <option value="+233">🇬🇭 Ghana (+233)</option>
            <option value="+254">🇰🇪 Kenya (+254)</option>
            <option value="+1">🇺🇸 USA (+1)</option>
            <option value="+44">🇬🇧 UK (+44)</option>
          </select>
        </div>
        <div>
          <label class="block font-medium mb-1">Phone Number</label>
          <input name="phone" placeholder="Enter your phone number" required
            class="w-full border rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-purple-500">
        </div>
        <label class="flex items-start gap-2 text-sm">
          <input type="checkbox" name="agree" class="mt-1">
          <span>I agree to the <a href="#" class="text-purple-600 underline">Terms and Conditions</a> and <a href="#" class="text-purple-600 underline">Privacy Policy</a></span>
        </label>
        <button class="w-full brand-gradient text-white font-semibold rounded-lg py-3">➤ Submit Contact</button>
      </form>
    <?php endif; ?>
  </div>
</div>

<div class="bg-white rounded-2xl shadow overflow-hidden">
  <div class="brand-gradient text-white px-6 py-4">
    <h2 class="font-bold flex items-center gap-2">💡 How It Works</h2>
  </div>
  <div class="p-6 text-sm text-gray-600 space-y-2">
    <p>1. Fill in your name and WhatsApp number above.</p>
    <p>2. Your contact is added to <?php echo h($bundle['business_name']); ?>'s contact list.</p>
    <p>3. You may be added to a WhatsApp group or contacted directly.</p>
  </div>
</div>
<?php require 'includes/footer.php'; ?>

<?php
require 'config.php';
require 'includes/auth.php';
require_login();
$user = current_user();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM bundles WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $user['id']]);
$bundle = $stmt->fetch();
if (!$bundle) { header('Location: dashboard.php'); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $suffix = trim($_POST['suffix'] ?? '');
    $release_days = max(1, min(15, (int)($_POST['release_days'] ?? 7)));
    $max_members = max(0, (int)($_POST['max_members'] ?? 0));
    $whatsapp_link = trim($_POST['whatsapp_link'] ?? '');

    if (!$name) {
        $error = 'Bundle name is required.';
    } else {
        $stmt = $pdo->prepare("UPDATE bundles SET name=?, suffix=?, release_days=?, max_members=?, whatsapp_link=? WHERE id=?");
        $stmt->execute([$name, $suffix, $release_days, $max_members, $whatsapp_link ?: null, $id]);
        header('Location: bundle.php?id=' . $id);
        exit;
    }
}

$page_title = 'Edit VCF Details';
require 'includes/header.php';
?>
<div class="bg-white rounded-2xl shadow p-6">
  <h1 class="text-2xl font-bold mb-6">Edit VCF Details</h1>
  <?php if ($error): ?>
    <div class="bg-red-50 text-red-600 text-sm rounded-lg px-3 py-2 mb-4"><?php echo h($error); ?></div>
  <?php endif; ?>
  <form method="post" class="space-y-5">
    <div>
      <label class="block font-medium mb-1">VCF Bundle Name</label>
      <input name="name" value="<?php echo h($bundle['name']); ?>" required class="w-full border rounded-lg px-3 py-2.5">
    </div>
    <div>
      <label class="block font-medium mb-1">Contact Suffix</label>
      <input name="suffix" value="<?php echo h($bundle['suffix']); ?>" class="w-full border rounded-lg px-3 py-2.5">
    </div>
    <div>
      <label class="block font-medium mb-1">Release Period (Days)</label>
      <input name="release_days" type="number" min="1" max="15" value="<?php echo h($bundle['release_days']); ?>" class="w-full border rounded-lg px-3 py-2.5">
    </div>
    <div>
      <label class="block font-medium mb-1">Max Members</label>
      <input name="max_members" type="number" min="0" value="<?php echo h($bundle['max_members']); ?>" class="w-full border rounded-lg px-3 py-2.5">
    </div>
    <div>
      <label class="block font-medium mb-1">Optional WhatsApp Link</label>
      <input name="whatsapp_link" value="<?php echo h($bundle['whatsapp_link']); ?>" placeholder="https://wa.me/234xxxxxxxxxx" class="w-full border rounded-lg px-3 py-2.5">
    </div>
    <button class="w-full brand-gradient text-white font-semibold rounded-lg py-3">Save Changes</button>
  </form>
  <a href="bundle.php?id=<?php echo $id; ?>" class="block text-center text-purple-600 mt-4">&larr; Back to bundle</a>
</div>
<?php require 'includes/footer.php'; ?>

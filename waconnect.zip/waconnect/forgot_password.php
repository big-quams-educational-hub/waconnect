<?php
require 'config.php';
require 'includes/auth.php';
$page_title = 'Forgot Password';
require 'includes/header.php';
?>
<div class="bg-white rounded-2xl shadow p-6 max-w-md mx-auto text-center">
  <h1 class="text-2xl font-bold mb-4">Forgot Password</h1>
  <p class="text-gray-500 text-sm mb-4">Password reset via email isn't wired up yet (needs an SMTP/mail service). For now, contact support to reset your password, or ask your developer to add mail-based reset here.</p>
  <a href="login.php" class="text-purple-600 font-medium">Back to Login</a>
</div>
<?php require 'includes/footer.php'; ?>

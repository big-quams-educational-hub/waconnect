<?php
require 'config.php';
require 'includes/auth.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['user_id'] = $user['id'];
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Invalid email or password.';
    }
}

$page_title = 'Login';
require 'includes/header.php';
?>
<div class="bg-white rounded-2xl shadow p-6 max-w-md mx-auto">
  <h1 class="text-2xl font-bold text-center mb-6">Login</h1>
  <?php if ($error): ?>
    <div class="bg-red-50 text-red-600 text-sm rounded-lg px-3 py-2 mb-4"><?php echo h($error); ?></div>
  <?php endif; ?>
  <form method="post" class="space-y-4">
    <input name="email" type="email" placeholder="Email" required
      class="w-full border rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-purple-500">
    <input name="password" type="password" placeholder="Password" required
      class="w-full border rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-purple-500">
    <button class="w-full brand-gradient text-white font-semibold rounded-lg py-2.5 hover:opacity-90">Login</button>
  </form>
  <p class="text-center text-sm mt-3"><a href="forgot_password.php" class="text-purple-600">Forgot Password?</a></p>
  <p class="text-center text-sm text-gray-500 mt-2">Don't have an account? <a href="register.php" class="text-purple-600 font-medium">Register</a></p>
</div>
<?php require 'includes/footer.php'; ?>

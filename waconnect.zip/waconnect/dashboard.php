<?php
require 'config.php';
require 'includes/auth.php';
require_login();
$user = current_user();

$stmt = $pdo->prepare("SELECT b.*, (SELECT COUNT(*) FROM contacts c WHERE c.bundle_id = b.id) as contact_count
                        FROM bundles b WHERE b.user_id = ? ORDER BY b.created_at DESC");
$stmt->execute([$user['id']]);
$bundles = $stmt->fetchAll();

$page_title = 'Dashboard';
require 'includes/header.php';
?>
<div class="brand-gradient text-white rounded-2xl p-6 mb-6">
  <h1 class="text-2xl font-bold">Welcome back, <?php echo h($user['business_name']); ?>!</h1>
  <p class="text-white/80 mt-1">Manage your VCF bundles and contacts</p>
</div>

<div class="bg-white rounded-2xl shadow p-6">
  <h2 class="text-xl font-bold mb-4">Your VCF Bundles</h2>
  <a href="create_bundle.php" class="block text-center brand-gradient text-white font-semibold rounded-lg py-3 mb-6 hover:opacity-90">+ Create New VCF</a>

  <?php if (!$bundles): ?>
    <p class="text-gray-400 text-center py-6">No bundles yet. Create your first one above.</p>
  <?php endif; ?>

  <?php foreach ($bundles as $b): ?>
    <div class="border rounded-xl p-4 mb-4">
      <div class="flex items-center justify-between mb-2">
        <span class="font-bold text-lg"><?php echo h($b['name']); ?></span>
        <span class="bg-blue-50 text-blue-600 text-sm font-medium px-3 py-1 rounded-full"><?php echo $b['contact_count']; ?> contacts</span>
      </div>
      <a href="bundle.php?id=<?php echo $b['id']; ?>" class="text-purple-600 font-medium text-sm">View bundle &rarr;</a>
    </div>
  <?php endforeach; ?>
</div>
<?php require 'includes/footer.php'; ?>

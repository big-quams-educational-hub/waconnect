<?php
require 'config.php';
require 'includes/auth.php';
require_login();
$user = current_user();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $suffix = trim($_POST['suffix'] ?? '');
    $release_days = max(1, min(15, (int)($_POST['release_days'] ?? 7)));
    $max_members = max(0, (int)($_POST['max_members'] ?? 0));
    $whatsapp_link = trim($_POST['whatsapp_link'] ?? '');

    if (!$name) {
        $error = 'Bundle name is required.';
    } else {
        do {
            $ref = generate_ref_code();
            $stmt = $pdo->prepare("SELECT id FROM bundles WHERE ref_code = ?");
            $stmt->execute([$ref]);
        } while ($stmt->fetch());

        $stmt = $pdo->prepare("INSERT INTO bundles (user_id, name, ref_code, suffix, release_days, max_members, whatsapp_link) VALUES (?,?,?,?,?,?,?)");
        $stmt->execute([$user['id'], $name, $ref, $suffix, $release_days, $max_members, $whatsapp_link ?: null]);
        header('Location: bundle.php?id=' . $pdo->lastInsertId());
        exit;
    }
}

$page_title = 'Create New VCF';
require 'includes/header.php';
?>
<div class="bg-white rounded-2xl shadow p-6">
  <h1 class="text-2xl font-bold mb-6">Create New VCF Bundle</h1>
  <?php if ($error): ?>
    <div class="bg-red-50 text-red-600 text-sm rounded-lg px-3 py-2 mb-4"><?php echo h($error); ?></div>
  <?php endif; ?>
  <form method="post" class="space-y-5">
    <div>
      <label class="block font-medium mb-1">VCF Bundle Name</label>
      <input name="name" placeholder="e.g., Tech Growth" required
        class="w-full border rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-purple-500">
    </div>
    <div>
      <label class="block font-medium mb-1">Contact Suffix</label>
      <input name="suffix" placeholder="e.g., -Guest"
        class="w-full border rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-purple-500">
      <p class="text-sm text-gray-400 mt-1">Appended to contact names</p>
    </div>
    <div>
      <label class="block font-medium mb-1">Release Period (Days)</label>
      <input name="release_days" type="number" min="1" max="15" value="7"
        class="w-full border rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-purple-500">
      <p class="text-sm text-gray-400 mt-1">Max 15 days</p>
    </div>
    <div>
      <label class="block font-medium mb-1">Max Members</label>
      <input name="max_members" type="number" min="0" value="0"
        class="w-full border rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-purple-500">
      <p class="text-sm text-gray-400 mt-1">0 = unlimited</p>
    </div>
    <div>
      <label class="block font-medium mb-1">Optional WhatsApp Link</label>
      <input name="whatsapp_link" placeholder="https://wa.me/234xxxxxxxxxx"
        class="w-full border rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-purple-500">
    </div>
    <button class="w-full brand-gradient text-white font-semibold rounded-lg py-3 hover:opacity-90">Generate VCF Bundle</button>
  </form>
</div>
<?php require 'includes/footer.php'; ?>

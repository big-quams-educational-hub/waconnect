<?php
require 'config.php';
require 'includes/auth.php';
require_login();
$user = current_user();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$bundle_id = (int)($_GET['bundle_id'] ?? $_POST['bundle_id'] ?? 0);

// Ensure contact belongs to a bundle owned by this user
$stmt = $pdo->prepare("SELECT c.* FROM contacts c JOIN bundles b ON b.id = c.bundle_id WHERE c.id = ? AND b.user_id = ?");
$stmt->execute([$id, $user['id']]);
$contact = $stmt->fetch();
if (!$contact) { header('Location: dashboard.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $country_code = trim($_POST['country_code'] ?? '+234');
    $phone = preg_replace('/\D/', '', $_POST['phone'] ?? '');

    $stmt = $pdo->prepare("UPDATE contacts SET full_name=?, country_code=?, phone=? WHERE id=?");
    $stmt->execute([$full_name, $country_code, $phone, $id]);
    header('Location: view_contacts.php?bundle_id=' . $bundle_id . '&edit=1');
    exit;
}

$page_title = 'Edit Contact';
require 'includes/header.php';
?>
<div class="bg-white rounded-2xl shadow p-6">
  <h1 class="text-2xl font-bold mb-6">Edit Contact</h1>
  <form method="post" class="space-y-4">
    <input type="hidden" name="id" value="<?php echo $id; ?>">
    <input type="hidden" name="bundle_id" value="<?php echo $bundle_id; ?>">
    <input name="full_name" value="<?php echo h($contact['full_name']); ?>" required class="w-full border rounded-lg px-3 py-2.5">
    <div class="flex gap-2">
      <input name="country_code" value="<?php echo h($contact['country_code']); ?>" class="border rounded-lg px-3 py-2.5 w-24">
      <input name="phone" value="<?php echo h($contact['phone']); ?>" required class="flex-1 border rounded-lg px-3 py-2.5">
    </div>
    <button class="w-full brand-gradient text-white font-semibold rounded-lg py-3">Save Changes</button>
  </form>
  <a href="view_contacts.php?bundle_id=<?php echo $bundle_id; ?>&edit=1" class="block text-center text-purple-600 mt-4">&larr; Back</a>
</div>
<?php require 'includes/footer.php'; ?>

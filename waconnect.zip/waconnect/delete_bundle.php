<?php
require 'config.php';
require 'includes/auth.php';
require_login();
$user = current_user();

$id = (int)($_POST['id'] ?? 0);
$stmt = $pdo->prepare("DELETE FROM bundles WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $user['id']]);

header('Location: dashboard.php');
exit;

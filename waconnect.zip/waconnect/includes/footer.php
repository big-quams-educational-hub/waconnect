</main>
<footer class="text-center text-sm text-gray-400 py-8">
  &copy; <?php echo date('Y'); ?> <?php echo h(BRAND_NAME); ?>. All rights reserved.
</footer>
</body>
</html>

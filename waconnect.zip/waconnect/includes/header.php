<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($page_title) ? h($page_title) . ' - ' . BRAND_NAME : BRAND_NAME; ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
  .brand-gradient { background: linear-gradient(135deg,#6D28D9,#2563EB); }
  .brand-gradient-text { background: linear-gradient(135deg,#6D28D9,#2563EB); -webkit-background-clip:text; background-clip:text; color:transparent; }
  body { background:#F3F2FB; }
</style>
</head>
<body class="min-h-screen text-gray-800">
<nav class="brand-gradient text-white shadow">
  <div class="max-w-3xl mx-auto flex items-center justify-between px-4 py-3">
    <a href="dashboard.php" class="font-bold text-lg flex items-center gap-2">
      <span>📇</span> <?php echo h(BRAND_NAME); ?>
    </a>
    <?php if (!empty($_SESSION['user_id'])): ?>
      <a href="logout.php" class="text-sm bg-white/20 px-3 py-1.5 rounded-lg hover:bg-white/30">Logout</a>
    <?php endif; ?>
  </div>
</nav>
<main class="max-w-3xl mx-auto px-4 py-6">

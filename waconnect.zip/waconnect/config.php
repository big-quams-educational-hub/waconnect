<?php
// ============================================
// EDIT THESE WITH YOUR HOSTING DB DETAILS
// ============================================
define('DB_HOST', 'localhost');
define('DB_NAME', 'waconnect');
define('DB_USER', 'root');
define('DB_PASS', '');

// Your brand name (shown across the site)
define('BRAND_NAME', 'BIG QUAMS MEDIA');

// Base URL of your site, no trailing slash e.g https://yourdomain.com
define('BASE_URL', 'https://yourdomain.com');

date_default_timezone_set('Africa/Lagos');

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

session_start();
